# OFF GAME — Games Offline by LIPS

Prototype project for an Android offline mini-game collection.

## Included
- 15 mini games
- Special "Siapa Impostor?" party game, 3–10 players
- Categories and Mix mode
- Private pass-the-phone reveal flow
- Local-only play; no internet permission or online service
- Android WebView wrapper project

## Build APK
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync and install Android SDK Platform 35 if requested.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK output is normally under `app/build/outputs/apk/debug/`.

## Notes
- This is a playable first version, not a guarantee of zero bugs on every device.
- Test on the target Android device before sharing.
- The impostor bank contains 1,000+ distinct entries across multiple themes. The game uses same-category alternate words; in Mix mode it uses a mixed pool.
- No internet permission is declared. All game data and code are bundled locally.
