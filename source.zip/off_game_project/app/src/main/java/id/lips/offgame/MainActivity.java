package id.lips.offgame;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;
public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().requestFeature(Window.FEATURE_NO_TITLE);
    getWindow().setStatusBarColor(Color.rgb(11,18,32));
    getWindow().setNavigationBarColor(Color.rgb(11,18,32));
    web = new WebView(this);
    web.setBackgroundColor(Color.rgb(11,18,32));
    WebSettings s=web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(false);
    s.setSupportZoom(false);
    web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
    web.loadUrl("file:///android_asset/index.html");
    setContentView(web);
  }
  @Override public void onBackPressed() {
    if(web!=null) web.evaluateJavascript("home()", null); else super.onBackPressed();
  }
}
